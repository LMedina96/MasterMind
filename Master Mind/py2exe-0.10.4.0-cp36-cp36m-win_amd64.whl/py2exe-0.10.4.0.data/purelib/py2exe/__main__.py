#!/usr/bin/python3.3
# -*- coding: utf-8 -*-
"""py2exe.__main__
"""

if __name__ == "__main__":
    from . import build_exe
    build_exe.main()
